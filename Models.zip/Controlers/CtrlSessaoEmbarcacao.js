"use strict";

import CtrlManterEmbarcacao from './CtrlManterEmbarcacao.js';
export default class CtrlSessaoEmbarcacao {
  
  //-----------------------------------------------------------------------------------------//
  
  constructor() {
    this.ctrlAtual = new CtrlManterEmbarcacao();
  }
  
  //-----------------------------------------------------------------------------------------//
}

var sessao = new CtrlSessaoEmbarcacao();

//------------------------------------------------------------------------//

