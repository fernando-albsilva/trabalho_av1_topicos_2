# Aspectos de configuração

1. Criar uma conta no GitHub

- Gerenciamento da Configuração:
  - versionamento
  - visões individuais do projeto (check in/chech out)

2. Criar uma conta no Glitch.me

- Login usando a conta do GitHub

3. New Project --> Opção glitch-hello-website

4. Para trocar o nome: [Settings][edit details][Edit Details] (novamente)

MOCK-UP: Protótipo/Desenho/Proposta Tela

# Como fazer o Upload de um arquivo para o projeto

1. [Assets][upload]
2. Clicar no arquivo (Asset) e copiar a URL
3. Abrir o [Terminal]
4. Efetuar o download com:
   $ wget -colar a url- (irá fazer download do arquivo para a área do projeto)
   para renomear:
5. Renomear o arquivo
   $ mv -nome estranho- -novo nome-

# Padrão para nomes

divXXX - para divs <br/>
tfXXX - para inputs de texto <br/>
btXXX - para botões <br/>
